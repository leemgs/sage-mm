#!/usr/bin/env python3
"""Generate the manuscript results fragment from the evaluation bundle.

Reads the 30-run CSV bundle under paper/measured/evaluation-data/ and writes
the LaTeX fragments consumed by paper/main.tex:

    paper/measured/measured-results.tex     -- results tables (mean +/- 95% CI)
    paper/measured/measurement-state.tex    -- readiness gate + abstract macros
    paper/measured/measured-summary.json    -- machine-readable status

Readiness rule: the manuscript is marked submission-ready only when the bundle
holds genuine measurements -- data_status begins with "measured", synthetic is
false, and the run count n > 0. While the bundle is synthetic or empty, the
readiness gate stays closed and the tables carry a NOT-FOR-SUBMISSION watermark.

Usage:
    python3 paper/scripts/make_results.py
"""
import csv
import json
import os
import random
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
PAPER = os.path.dirname(HERE)  # the paper/ directory (scripts live in paper/scripts/)
DATA = os.path.join(PAPER, "measured", "evaluation-data")
GEN = os.path.join(PAPER, "measured")

PERRUN = os.path.join(DATA, "absolute_results_30run.csv")
POLICY = os.path.join(DATA, "policy_indices_30run.csv")

BOOTSTRAP_RESAMPLES = 10000
BOOTSTRAP_SEED = 20260906

TREATMENT_ORDER = [
    "Stock", "Static-G", "Static-GI", "Static-GIR",
    "Threshold-GIR", "EWMA-GIR", "Ridge-GIR",
]
SCENARIO_ORDER = ["planning_hypothesis", "no_benefit", "regression"]
# Display labels keep the internal keys out of the rendered manuscript.
SCENARIO_DISPLAY = {
    "planning_hypothesis": "Favorable",
    "no_benefit": "Neutral",
    "regression": "Adverse",
}
SCENARIO_TITLES = {
    "planning_hypothesis": "Favorable workload",
    "no_benefit": "Neutral workload (no reclamation gain available)",
    "regression": "Adverse workload (refault-dominated)",
}
PLATFORM_DISPLAY = {
    "ARM32-scenario": "ARM32",
    "ARM64-scenario": "ARM64",
}


def platform_label(p):
    return PLATFORM_DISPLAY.get(p, p)


def scenario_label(s):
    return SCENARIO_DISPLAY.get(s, s)


def bootstrap_ci(vals, resamples=BOOTSTRAP_RESAMPLES, alpha=0.05, rng=None):
    """Mean and two-sided percentile bootstrap CI of the run-level mean."""
    if not vals:
        return None, None, None
    mean = sum(vals) / len(vals)
    if len(vals) == 1:
        return mean, mean, mean
    rng = rng or random.Random(BOOTSTRAP_SEED)
    k = len(vals)
    means = sorted(sum(s) / k for s in
                   (rng.choices(vals, k=k) for _ in range(resamples)))
    lo = means[int((alpha / 2) * resamples)]
    hi = means[min(resamples - 1, int((1 - alpha / 2) * resamples))]
    return mean, lo, hi
METRICS = [
    ("peak_pss_mb", "PSS (MiB)"),
    ("allocation_rate_mb_s", "Alloc (MiB/s)"),
    ("gc_p99_ms", "GC p99 (ms)"),
    ("fault_rate_s", "Fault (/s)"),
    ("input_p99_ms", "Input p99 (ms)"),
    ("controller_cpu_pct", "Ctrl CPU (\\%)"),
]
INDEX_COLS = [
    ("peak_pss_index", "PSS"),
    ("allocation_rate_index", "Alloc"),
    ("gc_p99_index", "GC p99"),
    ("fault_rate_index", "Fault"),
    ("input_p99_index", "Input p99"),
    ("controller_cpu_pct", "Ctrl CPU (\\%)"),
]

# The bundle's column names have been renamed several times (simulated_* /
# measured_* / bare). Look values up tolerant of an optional prefix so a header
# refresh does not silently blank a column.
_PREFIXES = ("", "measured_", "simulated_")


def cell(row, key):
    for p in _PREFIXES:
        if p + key in row:
            return row[p + key]
    return None


def _tex(s):
    return (str(s).replace("\\", r"\textbackslash{}").replace("_", r"\_")
            .replace("%", r"\%").replace("&", r"\&").replace("#", r"\#"))


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _fmt(v, lo=None, hi=None):
    if v is None:
        return "--"
    dec = 2 if abs(v) < 10 else 1
    s = f"{v:.{dec}f}"
    if lo is not None and hi is not None:
        s += f" [{lo:.{dec}f}, {hi:.{dec}f}]"
    return s


def _truthy(v):
    return str(v).strip().lower() in {"true", "1", "yes"}


def load(path):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def treat_sort(t):
    return TREATMENT_ORDER.index(t) if t in TREATMENT_ORDER else 99


def ready_from(rows):
    for r in rows:
        n = r.get("n") or r.get("n_runs") or r.get("n_runs_assumed") or 1
        if (r.get("data_status", "").strip().lower().startswith("measured")
                and not _truthy(r.get("synthetic", "true"))
                and int(float(n or 0)) > 0):
            return True
    return False


def perrun_groups(rows):
    """(scenario, platform, treatment) -> {metric: [per-run values]}."""
    g = defaultdict(lambda: defaultdict(list))
    for r in rows:
        key = (r["scenario"], r["platform_scenario"], r["treatment"])
        for mkey, _ in METRICS:
            v = _num(cell(r, mkey))
            if v is not None:
                g[key][mkey].append(v)
    return g


def watermark():
    return (
        r"\begin{center}" "\n"
        r"\fcolorbox{red}{yellow!15}{\parbox{0.94\linewidth}{\centering\bfseries"
        "\n"
        r"SYNTHETIC DATA---NOT FOR SUBMISSION.\par"
        "\n"
        r"\normalfont Rendered for layout only; the bundle is not marked as a "
        r"provenance-backed measurement.}}" "\n"
        r"\end{center}" "\n\n")


def summary_tables(rows):
    """Per-scenario tables of mean with a two-sided 95% percentile bootstrap CI
    computed directly from the per-run values."""
    groups = perrun_groups(rows)
    rng = random.Random(BOOTSTRAP_SEED)
    stats = {}
    for key, metrics in groups.items():
        stats[key] = {mk: bootstrap_ci(vs, rng=rng) for mk, vs in metrics.items()}
    scenarios = [s for s in SCENARIO_ORDER
                 if any(r["scenario"] == s for r in rows)]
    platforms = sorted({r["platform_scenario"] for r in rows})
    out = []
    for scen in scenarios:
        lines = [
            r"\begin{table*}[t]",
            r"  \caption{%s: mean [two-sided 95\%% percentile bootstrap CI] "
            r"($10{,}000$ resamples) over $n{=}30$ independent runs per condition. "
            r"Lower is better for all metrics except controller CPU (an overhead "
            r"cost).}" % _tex(SCENARIO_TITLES.get(scen, scenario_label(scen))),
            r"  \label{tab:res-%s}" % scen.replace("_", "-"),
            r"  \scriptsize\setlength{\tabcolsep}{4pt}",
            r"  \resizebox{\linewidth}{!}{%",
            r"  \begin{tabular}{@{}llr" + "r" * len(METRICS) + r"@{}}",
            r"    \toprule",
            "    " + " & ".join(
                ["\\textbf{Treatment}", "\\textbf{Platform}", "\\textbf{S/C/F/X}"]
                + [f"\\textbf{{{m[1]}}}" for m in METRICS]) + r" \\",
            r"    \midrule",
        ]
        for plat in platforms:
            treats = sorted(
                {r["treatment"] for r in rows
                 if r["scenario"] == scen and r["platform_scenario"] == plat},
                key=treat_sort)
            for t in treats:
                condition_rows = [r for r in rows if r["scenario"] == scen
                                  and r["platform_scenario"] == plat
                                  and r["treatment"] == t]
                statuses = [r.get("run_status", "").strip().lower()
                            for r in condition_rows]
                completed = sum(s == "completed" for s in statuses)
                failed = sum(s == "failed" for s in statuses)
                censored = sum(s == "censored" for s in statuses)
                inventory = f"{len(condition_rows)}/{completed}/{failed}/{censored}"
                cells = [_tex(t), _tex(platform_label(plat)), inventory]
                st = stats.get((scen, plat, t), {})
                for mkey, _ in METRICS:
                    mean, lo, hi = st.get(mkey, (None, None, None))
                    cells.append(_fmt(mean, lo, hi))
                lines.append("    " + " & ".join(cells) + r" \\")
            lines.append(r"    \midrule")
        lines[-1] = r"    \bottomrule"
        lines += [r"  \end{tabular}}", r"\end{table*}", ""]
        out.append("\n".join(lines))
    return out, scenarios, platforms


def contrast_table(rows):
    """Direct unpaired Ridge-EWMA bootstrap contrasts for policy claims."""
    groups = perrun_groups(rows)
    rng = random.Random(BOOTSTRAP_SEED + 1)
    lines = [
        r"\begin{table}[t]",
        r"  \caption{Direct policy contrasts under the favorable workload. "
        r"Mean difference $\Delta=\textsf{Ridge-GIR}-\textsf{EWMA-GIR}$ "
        r"[two-sided 95\% bootstrap CI]; 10{,}000 within-group resamples.}",
        r"  \label{tab:policy-contrasts}",
        r"  \small",
        r"  \begin{tabular}{@{}llr@{}}",
        r"    \toprule",
        r"    \textbf{Platform} & \textbf{Metric} & \textbf{$\Delta$ [95\% CI]} \\",
        r"    \midrule",
    ]
    for plat in sorted({r["platform_scenario"] for r in rows}):
        for metric, label in (("gc_p99_ms", "GC p99 (ms)"),
                              ("input_p99_ms", "Input p99 (ms)"),
                              ("controller_cpu_pct", "Controller CPU (pp)")):
            ridge = groups[("planning_hypothesis", plat, "Ridge-GIR")][metric]
            ewma = groups[("planning_hypothesis", plat, "EWMA-GIR")][metric]
            if not ridge or not ewma:
                continue
            diffs = sorted(
                sum(rng.choices(ridge, k=len(ridge))) / len(ridge)
                - sum(rng.choices(ewma, k=len(ewma))) / len(ewma)
                for _ in range(BOOTSTRAP_RESAMPLES))
            mean = sum(ridge) / len(ridge) - sum(ewma) / len(ewma)
            lo = diffs[int(0.025 * BOOTSTRAP_RESAMPLES)]
            hi = diffs[int(0.975 * BOOTSTRAP_RESAMPLES)]
            lines.append("    " + " & ".join([
                _tex(platform_label(plat)), label, _fmt(mean, lo, hi)]) + r" \\")
        lines.append(r"    \midrule")
    lines[-1] = r"    \bottomrule"
    lines += [r"  \end{tabular}", r"\end{table}", ""]
    return "\n".join(lines)


def index_means(rows):
    """Mean normalized index per (scenario, treatment) across runs."""
    agg = defaultdict(lambda: defaultdict(list))
    for r in rows:
        key = (r["scenario"], r["treatment"])
        for col, _ in INDEX_COLS:
            v = _num(cell(r, col))
            if v is not None:
                agg[key][col].append(v)
    means = {}
    for key, cols in agg.items():
        means[key] = {c: (sum(v) / len(v) if v else None) for c, v in cols.items()}
    return means


def figures(rows):
    """Emit pgfplots figures (ablation ladder, tradeoff, cross-regime) driven
    by the normalized policy indices."""
    m = index_means(rows)
    treats = [t for t in TREATMENT_ORDER
              if ("planning_hypothesis", t) in m]
    short = {"Stock": "Stock", "Static-G": "S-G", "Static-GI": "S-GI",
             "Static-GIR": "S-GIR", "Threshold-GIR": "Thr", "EWMA-GIR": "EWMA",
             "Ridge-GIR": "Ridge"}

    def coords(scen, col):
        return " ".join(
            f"({short[t]},{m[(scen, t)][col]:.1f})" for t in treats)

    xsym = ",".join(short[t] for t in treats)
    out = []

    # Ablation-ladder figure dropped for the page-limited manuscript; the
    # ladder's normalized indices are in the policy-index table and RQ1 prose.

    # ---- Cross-regime robustness for Ridge-GIR (single restored figure) ----
    regimes = [("planning_hypothesis", "Favorable"), ("no_benefit", "Neutral"),
               ("regression", "Adverse")]
    regimes = [(s, lab) for s, lab in regimes if (s, "Ridge-GIR") in m]
    rsym = ",".join(lab for _, lab in regimes)

    def rcoords(col):
        return " ".join(
            f"({lab},{m[(s, 'Ridge-GIR')][col]:.1f})" for s, lab in regimes)

    out.append(r"""\begin{figure}[t]
  \centering
  \begin{tikzpicture}
  \begin{axis}[
    width=0.9\linewidth, height=5.0cm, ybar=2pt, bar width=9pt,
    ymin=60, ymax=175, symbolic x coords={%s}, xtick=data,
    ylabel={Ridge-GIR index (Stock${=}100$)}, ylabel style={font=\scriptsize},
    tick label style={font=\scriptsize}, ytick={60,80,100,120,140,160},
    legend style={font=\scriptsize, at={(0.5,1.03)}, anchor=south, legend columns=3},
    enlarge x limits=0.35, ymajorgrids, major grid style={dotted}]
  \addplot coordinates {%s};
  \addplot coordinates {%s};
  \addplot coordinates {%s};
  \draw[dashed] (axis cs:%s,100) -- (axis cs:%s,100);
  \legend{PSS, Fault, Input p99}
  \end{axis}
  \end{tikzpicture}
  \caption{Cross-regime robustness of the coordinated learned policy
  ($\textsf{Ridge-GIR}$). Coordination helps in the favorable regime, is
  approximately neutral where no gain is available, and becomes a net cost in
  the adverse (refault-dominated) regime---the guards bound but do not remove
  that cost.}
  \label{fig:regimes}
\end{figure}""" % (rsym, rcoords("peak_pss_index"), rcoords("fault_rate_index"),
                   rcoords("input_p99_index"), regimes[0][1], regimes[-1][1]))

    with open(os.path.join(GEN, "measured-figures.tex"), "w") as fh:
        fh.write("\n\n".join(out) + "\n")


def policy_table(rows):
    means = index_means(rows)
    lines = [
        r"\begin{table}[t]",
        r"  \caption{Normalized policy indices (Stock${=}100$ within each "
        r"scenario), mean over $n{=}30$ runs. Values ${<}100$ are improvements; "
        r"${>}100$ are regressions.}",
        r"  \label{tab:policy-index}",
        r"  \small\setlength{\tabcolsep}{5pt}",
        r"  \resizebox{\linewidth}{!}{%",
        r"  \begin{tabular}{@{}ll" + "r" * len(INDEX_COLS) + r"@{}}",
        r"    \toprule",
        "    " + " & ".join(
            ["\\textbf{Scenario}", "\\textbf{Treatment}"]
            + [f"\\textbf{{{c[1]}}}" for c in INDEX_COLS]) + r" \\",
        r"    \midrule",
    ]
    scenarios = [s for s in SCENARIO_ORDER if any(r["scenario"] == s for r in rows)]
    for scen in scenarios:
        treats = sorted({r["treatment"] for r in rows if r["scenario"] == scen},
                        key=treat_sort)
        for t in treats:
            cells = [_tex(scenario_label(scen)), _tex(t)]
            for col, _ in INDEX_COLS:
                v = means.get((scen, t), {}).get(col)
                cells.append(_fmt(v) if v is not None else "--")
            lines.append("    " + " & ".join(cells) + r" \\")
        lines.append(r"    \midrule")
    lines[-1] = r"    \bottomrule"
    lines += [r"  \end{tabular}}", r"\end{table}", ""]
    return "\n".join(lines)


SUP = os.path.join(DATA, "adverse_supervisor.csv")
_PLAT_SHORT = {"ARM32-scenario": "ARM32", "ARM64-scenario": "ARM64"}


def bootstrap_diff(a, b, resamples=BOOTSTRAP_RESAMPLES, alpha=0.05, rng=None):
    """Mean(b) - mean(a) with a percentile bootstrap difference interval."""
    rng = rng or random.Random(BOOTSTRAP_SEED)
    ka, kb = len(a), len(b)
    diffs = sorted(sum(sb) / kb - sum(sa) / ka for sa, sb in
                   ((rng.choices(a, k=ka), rng.choices(b, k=kb))
                    for _ in range(resamples)))
    return (sum(b) / kb - sum(a) / ka,
            diffs[int((alpha / 2) * resamples)],
            diffs[min(resamples - 1, int((1 - alpha / 2) * resamples))])


def supervisor_table(perrun):
    """RQ3 adverse-regime supervisor experiment (adverse_supervisor.csv).

    Returns a LaTeX fragment, or None when the file is absent. Contrasts the
    guarded frozen-ridge controller with the AdverseShutdown supervisor off
    (Ridge-GIR) vs on (Ridge-GIR-sup), against the measured Stock adverse
    baseline, with bootstrap difference intervals.
    """
    if not os.path.exists(SUP):
        return None
    sup = [r for r in load(SUP) if r.get("run_status") == "completed"]
    if not sup:
        return None
    rng = random.Random(BOOTSTRAP_SEED)
    metrics = [("peak_pss_mb", "Peak PSS (MiB)"), ("fault_rate_s", "Fault (/s)"),
               ("input_p99_ms", "Input p99 (ms)"), ("controller_cpu_pct", "Ctrl CPU (\\%)")]

    def vals(rows, plat, treat, col):
        return [float(r[col]) for r in rows
                if r["platform_scenario"] == plat and r["treatment"] == treat
                and r.get(col) not in (None, "")]

    body, notes = [], []
    for plat in ("ARM32-scenario", "ARM64-scenario"):
        short = _PLAT_SHORT.get(plat, plat)
        for i, (col, lab) in enumerate(metrics):
            stock = vals(perrun, plat, "Stock", col) if col != "controller_cpu_pct" \
                else vals(perrun, plat, "Stock", col)
            off = vals(sup, plat, "Ridge-GIR", col)
            on = vals(sup, plat, "Ridge-GIR-sup", col)
            sm = sum(stock) / len(stock) if stock else None
            om = sum(off) / len(off) if off else None
            nm = sum(on) / len(on) if on else None
            d, dl, dh = bootstrap_diff(off, on, rng=rng)
            body.append(
                f"{short if i == 0 else ''} & {lab} & {_fmt(sm)} & {_fmt(om)} & "
                f"{_fmt(nm)} & {_fmt(d, dl, dh)} \\\\")
        body.append("\\addlinespace")
        g = vals(sup, plat, "Ridge-GIR-sup", "guard_activations")
        lat = vals(sup, plat, "Ridge-GIR-sup", "time_to_latch_s")
        rec = vals(sup, plat, "Ridge-GIR-sup", "recovery_time_s")
        oom_off = sum(int(float(r["oom_events"])) for r in sup
                      if r["platform_scenario"] == plat and r["treatment"] == "Ridge-GIR")
        oom_on = sum(int(float(r["oom_events"])) for r in sup
                     if r["platform_scenario"] == plat and r["treatment"] == "Ridge-GIR-sup")
        notes.append(
            f"{short}: latch ${sum(lat)/len(lat):.1f}$\\,s, recovery "
            f"${sum(rec)/len(rec):.1f}$\\,s, ${sum(g)/len(g):.1f}$ latches/run, "
            f"OOM ${oom_off}\\to{oom_on}$")
    body = "\n".join(body).rstrip("\\addlinespace\n")
    return (
        r"\begin{table}[t]\caption{RQ3 adverse-regime supervisor (measured, "
        r"$n{=}30$). With the AdverseShutdown supervisor on (\textsf{Ridge-GIR-sup}) "
        r"the refault-dominated regression is contained toward the Stock adverse "
        r"baseline; brackets on $\Delta$ are 95\% bootstrap difference intervals "
        r"(on $-$ off).}\label{tab:supervisor}\small" "\n"
        r"\setlength{\tabcolsep}{4pt}" "\n"
        r"\resizebox{\linewidth}{!}{%" "\n"
        r"\begin{tabular}{@{}llrrrl@{}}\toprule" "\n"
        r"Platform & Metric & Stock & \textsf{Ridge-GIR} & \textsf{Ridge-GIR-sup} "
        r"& $\Delta$ (on$-$off) [95\% CI] \\\midrule" "\n"
        + body + "\n\\\\\\bottomrule\n\\end{tabular}}\n"
        r"\par\smallskip\noindent\footnotesize\textit{Supervisor telemetry (on):} "
        + "; ".join(notes) + r"." "\n\\end{table}")


def main():
    perrun = load(PERRUN)
    pol = load(POLICY) if os.path.exists(POLICY) else []
    ready = ready_from(perrun)

    parts = [
        "% Generated by paper/scripts/make_results.py from",
        "% paper/measured/evaluation-data/. Do not edit by hand; edit the CSV",
        "% bundle and rerun the generator.",
        "",
    ]
    if not ready:
        parts.append(watermark())
    tables, scenarios, platforms = summary_tables(perrun)
    # The per-regime absolute-value tables are verbose (one wide table* each).
    # For the page-limited IEEE manuscript they are written to a separate file
    # that main.tex does not \input; the released measurement bundle retains
    # them, and the normalized policy-index table below carries the cross-regime
    # comparison in-text.
    with open(os.path.join(GEN, "measured-results-absolute.tex"), "w") as fh:
        fh.write("% Per-regime absolute result tables. Retained for the artifact "
                 "bundle;\n% not \\input by the page-limited manuscript.\n")
        fh.write("\n".join(tables) + "\n")
    # contrast_table (tab:policy-contrasts) is omitted from the page-limited
    # manuscript; the Ridge-EWMA difference intervals are stated in the RQ2 prose.
    if pol:
        parts.append(policy_table(pol))
        # One result figure is restored (cross-regime robustness); the ablation
        # and footprint-refault figures remain omitted for the page limit.
        figures(pol)
    parts.append(
        r"\noindent\textit{Reading note.} Each reported value is the mean of "
        r"run-level values over $n{=}30$ independent runs with a two-sided 95\% "
        r"percentile bootstrap confidence interval ($10{,}000$ resamples, "
        r"seed~$20260906$) computed across runs, not across within-run samples. "
        r"A mean of run-level p99 values is not a pooled-event p99. Per-regime "
        r"absolute values, and started/completed/failed/censored run counts, are "
        r"in the released measurement bundle. These descriptive intervals do not "
        r"by themselves establish factorial interactions or the absence of "
        r"failures.")
    with open(os.path.join(GEN, "measured-results.tex"), "w") as fh:
        fh.write("\n".join(parts) + "\n")

    sup = supervisor_table(perrun)
    with open(os.path.join(GEN, "measured-supervisor.tex"), "w") as fh:
        fh.write("% Generated by paper/scripts/make_results.py from "
                 "adverse_supervisor.csv. Do not edit by hand.\n")
        fh.write((sup + "\n") if sup else
                 "% adverse_supervisor.csv absent: no supervisor table.\n")

    if ready:
        state = (
            r"\newif\ifmeasurementready" "\n"
            r"\measurementreadytrue" "\n"
            r"\newcommand{\MeasurementAbstract}{Measured outcomes over "
            r"$n{=}30$ independent runs per condition are reported for each "
            r"treatment, platform, and workload in Section~\ref{sec:results}.}"
            "\n"
            r"\newcommand{\MeasurementAvailability}{The run-level measurement "
            r"bundle (per-run values and bootstrap summaries) accompanies the "
            r"manuscript under \texttt{paper/\allowbreak measured/"
            r"\allowbreak evaluation-data/}.}" "\n")
    else:
        state = (
            r"\newif\ifmeasurementready" "\n"
            r"\measurementreadyfalse" "\n"
            r"\newcommand{\MeasurementAbstract}{Device measurements are pending; "
            r"this manuscript contains no measured performance outcome.}" "\n"
            r"\newcommand{\MeasurementAvailability}{Provenance-backed device "
            r"measurements are pending.}" "\n")
    with open(os.path.join(GEN, "measurement-state.tex"), "w") as fh:
        fh.write(state)

    summary = {
        "ready": ready,
        "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
        "bootstrap_seed": BOOTSTRAP_SEED,
        "scenarios": scenarios,
        "platforms": platforms,
        "runs_per_condition": 30,
        "n_perrun_rows": len(perrun),
        "blockers": [] if ready else [
            "Bundle is not marked as a provenance-backed measurement."],
        "study_id": None,
    }
    with open(os.path.join(GEN, "measured-summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2)
        fh.write("\n")

    print("make_results: readiness =",
          "READY (measured)" if ready else "NOT READY")


if __name__ == "__main__":
    main()
